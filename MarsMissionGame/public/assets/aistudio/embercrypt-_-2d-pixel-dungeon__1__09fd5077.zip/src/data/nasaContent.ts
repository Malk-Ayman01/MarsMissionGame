import { DialogueLine, EducationalFact } from '../types/game';

export const NASA_FACTS: EducationalFact[] = [

  {
    id: 'jezero_crater',
    title: 'Jezero Crater: An Old Lake on Mars',
    subtitle: 'Where NASA Sent the Perseverance Rover',
    category: 'GEOLOGY',
    imageSrc: '/assets/nasa/jezero_crater.jpg',
    imageCaption: 'NASA picture of Jezero Crater on Mars (curved ancient river delta).',
    nasaFact:
      'Long ago, Jezero Crater (45 km wide and ~2,500 meters deep below average Mars ground!) was a big lake full of water! Rivers carried mud and clay into the lake. Today, each sol (one Mars day — 24 hours and 39 minutes) is freezing cold with very thin air, so astronauts must wear pressurized spacesuits.',
    olderKidsNote:
      'Orbital elevation maps show Jezero Crater sitting around -2,500 meters elevation where the Neretva river delta flowed in. Surface air pressure stays near ~710–760 Pa (under 1% of Earth) and background radiation is ~0.64 mSv/day.',
    classroomPrompt:
      'Class Question: Why can liquid rivers NOT flow on Mars today even though Jezero Crater held a giant lake 3.5 billion years ago?',
    gameContext:
      'In Mission 1, your damaged ship and broken radio tower sit on this rocky lake edge during real Mars Sol weather.',
    sourceName: 'NASA Mars 2020 Perseverance & MSL RAD',
    sourceUrl: 'https://science.nasa.gov/mission/mars-2020-perseverance/',
    missionId: 'mission_1',
    unlockedAtStage: 'stage_1_leave_habitat',
    instrumentName: 'Space Orbiter Camera & MEDA',
    solObservation: 'Jezero Crater',
    datasetType: 'REAL_NASA_OBSERVATION',
  },
  {
    id: 'mars_food_production',
    title: 'Growing Food on Mars (Space Farming!)',
    subtitle: 'Why Hydroponics Beats Planting in Mars Dirt',
    category: 'POWER SYSTEMS',
    imageSrc: '/assets/nasa/meda_weather_station.jpg',
    imageCaption: 'NASA weather sensors checking Mars sunlight and dust levels needed for greenhouses.',
    nasaFact:
      'Food rockets from Earth take 7 to 9 months! So Mars astronauts grow lettuce and veggies using hydroponics (growing plants in clean water instead of dirt), because real Mars dirt has yucky salty chemicals called perchlorates. Plants also turn astronaut breath back into fresh oxygen!',
    olderKidsNote:
      'Mars only receives ~43% of Earth sunlight (~590 W/m² peak) — and during dusty Sols (Tau 1.65) sunlight drops near ~18%! So NASA Veggie / Advanced Plant Habitat LED grow lights demand heavy electric power, creating a real trade-off with rover battery and habitat heaters.',
    classroomPrompt:
      'Explore Question: Why is growing plants in clean water with space lights safer than using real Mars dirt?',
    gameContext:
      'Whenever you walk inside the green circle at your base, your Suit Air fills back up using real life-support oxygen science!',
    sourceName: 'NASA Growing Plants in Space (VEGGIE & APH)',
    sourceUrl: 'https://www.nasa.gov/missions/station/iss-research/growing-plants-in-space/',
    missionId: 'mission_1',
    unlockedAtStage: 'stage_3_drive_rover',
    instrumentName: 'NASA VEGGIE / APH & MEDA Sunlight Data',
    solObservation: 'Sol Crop Study',
    datasetType: 'REAL_NASA_OBSERVATION',
  },
  {
    id: 'equipment_maintenance',
    title: 'Fixing Broken Tools on Mars',
    subtitle: 'Why Spare Parts Keep Astronauts Safe',
    category: 'ROVER TECH',
    imageSrc: '/assets/nasa/perseverance_rover.jpg',
    imageCaption: 'NASA Perseverance rover and Ingenuity helicopter working on Mars.',
    nasaFact:
      'It takes about 7 months for a supply rocket to bring new things from Earth to Mars! So astronauts and rovers must carry spare parts and fix broken tools right away using what they have.',
    olderKidsNote:
      'NASA launches Mars transfer missions only once every ~26 months when Earth and Mars line up (Hohmann transfer window). Carrying extra mass costs huge rocket fuel, forcing tight weight trade-offs.',
    classroomPrompt:
      'Design Challenge: If you could only pack 3 spare parts for a 500-day Mars trip, which tools would you pick first?',
    gameContext:
      'You pick up a spare power part from the orange box so you can fix the broken radio tower yourself.',
    sourceName: 'NASA Mars Rover Pictures',
    sourceUrl: 'https://mars.nasa.gov/mars2020/multimedia/raw-images/',
    missionId: 'mission_1',
    unlockedAtStage: 'stage_2_collect_coupler',
    instrumentName: 'Rover Camera',
    solObservation: 'Sol 46',
    datasetType: 'REAL_NASA_OBSERVATION',
  },
  {
    id: 'space_communications',
    title: 'Radio Delay: Waiting for Earth to Answer!',
    subtitle: 'Why Messages Take 7 to 42 Minutes Round-Trip',
    category: 'COMMUNICATIONS',
    imageSrc: '/assets/nasa/deep_space_network.jpg',
    imageCaption: 'A giant 70-meter NASA Deep Space Network radio dish on Earth listening to Mars.',
    nasaFact:
      'Mars is 55 to 401 million kilometers away! Even at the speed of light, a radio "HELLO!" takes 3 to 21 minutes just to arrive on Earth — so waiting for an answer takes up to 42 minutes! That is why Mars crews must make quick safety choices on their own.',
    olderKidsNote:
      'Radio waves travel at c = 299,792 km/s. When Mars is near solar conjunction (378+ million km), one-way light-time lag hits ~21 minutes (42 min round trip). NASA rovers use onboard autonomous hazard avoidance instead of Earth joystick control.',
    classroomPrompt:
      'Math Check: If Mars is 252 million km away and light travels ~18 million km per minute, how long do you wait to hear back after asking Earth for help?',
    gameContext:
      'Watch the Light-Time Radio Delay readout in your mission header — and notice why astronauts must think fast in storms!',
    sourceName: 'NASA Deep Space Network',
    sourceUrl: 'https://www.nasa.gov/directorates/somd/space-communications-navigation-program/deep-space-network/',
    missionId: 'mission_1',
    unlockedAtStage: 'stage_4_repair_relay',
    instrumentName: 'Deep Space Network 70m Antenna',
    solObservation: 'Light-Time Telemetry',
    datasetType: 'REAL_NASA_OBSERVATION',
  },
  {
    id: 'martian_dust_storms',
    title: 'Big Dust Storms on Mars',
    subtitle: 'Tiny Powder Dust & Solar Blackouts',
    category: 'ATMOSPHERE',
    imageSrc: '/assets/nasa/mars_dust_storm.jpg',
    imageCaption: 'Mars before (left) and during (right) a giant planet-wide dust storm.',
    nasaFact:
      'Mars has very thin air, so wind does not push hard. But Mars dust is tiny like baby powder! Big storms can block sunlight from solar panels and greenhouses, and clog spacesuit air filters.',
    olderKidsNote:
      'Perseverance MEDA measures atmospheric dust using optical depth ("Tau"). Clear skies measure Tau ~0.4, while heavy storms exceed Tau 1.65–5.0, slashing solar energy and cooling daytime highs.',
    classroomPrompt:
      'Science Link: How does a planet-wide dust storm affect both rover batteries and indoor greenhouse plants at the same time?',
    gameContext:
      'When the storm arrives, it gets harder to see and your Suit Air drains twice as fast. Hurry back inside!',
    sourceName: 'NASA Mars Science & MEDA',
    sourceUrl: 'https://science.nasa.gov/mission/mars-2020-perseverance/science/',
    missionId: 'mission_1',
    unlockedAtStage: 'stage_5_escape_storm',
    instrumentName: 'MEDA Dust Sensor & Orbiter Camera',
    solObservation: 'Dust Tau Study',
    datasetType: 'REAL_NASA_OBSERVATION',
  },

  {
    id: 'rimfax_subsurface_radar',
    title: 'Looking Underground with Radar',
    subtitle: 'How NASA Sees Under Mars Dirt',
    category: 'GEOLOGY',
    imageSrc: '/assets/nasa/rimfax_radar.jpg',
    imageCaption: 'NASA RIMFAX radar map showing hidden rock layers under the ground.',
    nasaFact:
      'Perseverance has a special tool called RIMFAX. It sends radio waves 10 meters down into the ground to spot hidden rock layers and buried caves without digging!',
    olderKidsNote:
      'RIMFAX is a ground-penetrating radar operating at 150–1,200 MHz, helping scientists locate ancient lake sediments and buried lava channels beneath Jezero Crater.',
    classroomPrompt:
      'Think Like a Scientist: Why is radar scanning safer and faster than drilling holes everywhere at random?',
    gameContext:
      'Watch your Cave Signal bar and listen to the beeps to find where to drop both ground sensors.',
    sourceName: 'NASA RIMFAX Radar',
    sourceUrl: 'https://mars.nasa.gov/mars2020/spacecraft/instruments/rimfax/',
    missionId: 'mission_2',
    unlockedAtStage: 'm2_stage_1_canyon_transit',
    instrumentName: 'RIMFAX Subsurface Radar',
    solObservation: 'Sol 210',
    datasetType: 'REAL_NASA_OBSERVATION',
  },
  {
    id: 'neretva_vallis_floods',
    title: 'Neretva Valley: An Ancient River',
    subtitle: 'Carved by Rushing Water Long Ago',
    category: 'GEOLOGY',
    imageSrc: '/assets/nasa/neretva_vallis.jpg',
    imageCaption: 'A dry ancient river valley on Mars called Neretva Vallis.',
    nasaFact:
      'Over 3 billion years ago, huge floods of water rushed through this valley and carried mud and clay into Jezero Crater! Clay rocks can even trap tiny signs of ancient water.',
    olderKidsNote:
      'Steep canyon walls like Neretva Vallis also partially shield explorers from incoming cosmic rays by blocking wide angles of the Martian sky, though loose windblown sand costs rovers extra battery torque.',
    classroomPrompt:
      'Compare Routes: Why might mission planners choose a slower, sandy canyon floor over a fast, exposed flat ridge during a solar storm?',
    gameContext:
      'You drive into this old river valley to place Ground Sensor 1.',
    sourceName: 'NASA Neretva Vallis',
    sourceUrl: 'https://science.nasa.gov/mission/mars-2020-perseverance/science/',
    missionId: 'mission_2',
    unlockedAtStage: 'm2_stage_2_deploy_beacons',
    instrumentName: 'Orbiter Map',
    solObservation: 'Sol 1140',
    datasetType: 'REAL_NASA_OBSERVATION',
  },
  {
    id: 'martian_lava_tubes',
    title: 'Caves That Block Space Rays! (Lava Tubes)',
    subtitle: 'Natural Shields Against Radiation Dose',
    category: 'SUBTERRANEAN',
    imageSrc: '/assets/nasa/mars_lava_tube.jpg',
    imageCaption: 'A hole (skylight) on Mars leading down into an underground lava cave.',
    nasaFact:
      'Mars does not have a strong magnetic shield like Earth, so harmful space rays (radiation dose) hit the ground! Underground volcano caves called lava tubes have thick stone roofs that block ~95% of space rays and keep astronauts safer than even the International Space Station!',
    olderKidsNote:
      'ISS radiation dosimeters record around ~0.52 mSv/day in orbit and Mars rovers measure ~0.64 mSv/day (jumping past 3.8 mSv/day during solar storms). Under thick lava-tube rock, radiation drops ~95% to roughly ~0.03 mSv/day.',
    classroomPrompt:
      'Mission Planning: How could future Mars habitats inside lava tubes stay warm and grow food without natural sunlight?',
    gameContext:
      'When you enter the cave in Mission 2, your HUD shows 95% Space Rays Blocked — protecting your Shielding meter!',
    sourceName: 'NASA Mars Caves & Curiosity RAD',
    sourceUrl: 'https://science.nasa.gov/mission/msl-curiosity/',
    missionId: 'mission_2',
    unlockedAtStage: 'm2_stage_3_lava_tube_entry',
    instrumentName: 'HiRISE Camera & RAD Radiation Data',
    solObservation: 'Volcanic Cave Shelter',
    datasetType: 'REAL_NASA_OBSERVATION',
  },
  {
    id: 'sample_core_caching',
    title: 'Drilling a Mars Rock Sample',
    subtitle: 'Saving Clean Rocks in Metal Tubes',
    category: 'ROVER TECH',
    imageSrc: '/assets/nasa/sample_core_tube.jpg',
    imageCaption: 'A shiny titanium tube holding a real finger-sized piece of Mars rock.',
    nasaFact:
      'NASA uses a spinning drill on the rover arm to cut out finger-sized rock pieces (~10–15 grams) and seal them inside super clean metal tubes to study in Earth labs.',
    olderKidsNote:
      'Perseverance carries 43 ultra-clean titanium sample tubes sterilized to avoid contaminating Mars rocks with Earth microbes before Mars Sample Return.',
    classroomPrompt:
      'Lab Check: Why do NASA scientists work so hard to keep the inside of sample tubes cleaner than a hospital operating room?',
    gameContext:
      'Use the rock drill inside the cave to collect Rock Tube #14 before the ground starts shaking!',
    sourceName: 'NASA Mars Sample Return',
    sourceUrl: 'https://science.nasa.gov/mission/mars-sample-return/',
    missionId: 'mission_2',
    unlockedAtStage: 'm2_stage_4_sample_extraction',
    instrumentName: 'Rover Percussive Drill',
    solObservation: 'Sol 194',
    datasetType: 'REAL_NASA_OBSERVATION',
  },

  {
    id: 'sample_caching_heritage',
    title: 'Saving Power Under Tight Limits (400W Budget)',
    subtitle: 'Choosing Your Helpful Upgrade When Dust Breaks a Heater',
    category: 'POWER SYSTEMS',
    imageSrc: '/assets/nasa/meda_weather_station.jpg',
    imageCaption: 'Rover weather and heat sensors checking Mars dust.',
    nasaFact:
      'Fine Mars dust sticks to wires and heaters! When one broken part wastes too much electricity, engineers flip it OFF first and choose which helpful tool to boost so the rover reaches the rocket safely.',
    olderKidsNote:
      'NASA rovers run on careful power budgets (~110–400W active subsystems). Turning off faulty heaters keeps Drive Motors, Life Support, and Science tools running smoothly.',
    classroomPrompt:
      'Next Task Choice: With Broken Heater #2 switched off, would you like Ray & Dust Shield, Rock Scanner, or Battery Boost for the drive to the rocket?',
    gameContext:
      'In Mission 3, Hedeya teaches you why Heater #2 drains power—flip it OFF, then pick your favorite helper upgrade for the next task!',
    sourceName: 'NASA MEDA Sensors',
    sourceUrl: 'https://mars.nasa.gov/mars2020/spacecraft/instruments/meda/',
    missionId: 'mission_3',
    unlockedAtStage: 'm3_stage_1_grid_triage',
    instrumentName: 'Power & Dust Sensors',
    solObservation: 'Sol 249',
    datasetType: 'REAL_NASA_OBSERVATION',
  },
  {
    id: 'mars_ascent_vehicle',
    title: 'Launching a Rocket Into Microgravity!',
    subtitle: 'Two-Stage Ascent & Autonomous Orbital Docking',
    category: 'NAVIGATION',
    imageSrc: '/assets/nasa/perseverance_rover.jpg',
    imageCaption: 'NASA plan to launch Mars rock tubes into orbit around Mars to meet an Earth ship.',
    nasaFact:
      'A Mars Rocket has two parts: Stage 1 pushes hard up through the sky and drops off when empty. Then Stage 2 zooms into microgravity (where things float gently in orbit!) and lines up on its own because Earth is too far away to steer live!',
    olderKidsNote:
      'Mars gravity is ~38% of Earth (3.72 m/s²). Because of the 7–21 minute one-way Earth communication delay, a Mars Ascent Vehicle (MAV) must steer its gravity turn and orbital rendezvous autonomously.',
    classroomPrompt:
      'Engineering Question: Why could someone on Earth NEVER use a video game controller to steer a Mars rocket landing or launch live?',
    gameContext:
      'Steer with A and D inside the green box, press SPACE to drop Stage 1, and gently dock in microgravity!',
    sourceName: 'NASA Mars Sample Return',
    sourceUrl: 'https://science.nasa.gov/mission/mars-sample-return/',
    missionId: 'mission_3',
    unlockedAtStage: 'm3_stage_4_mav_ascent',
    instrumentName: 'Mars Ascent Vehicle (MAV)',
    solObservation: 'Autonomous Orbit',
    datasetType: 'REAL_NASA_OBSERVATION',
  },
  {
    id: 'astronaut_health_microgravity',
    title: 'Staying Healthy in Space (Bones, Muscles & Sleep)',
    subtitle: 'How Long Space Trips Change Astronaut Bodies',
    category: 'SPACE BIOLOGY',
    imageSrc: '/assets/nasa/meda_weather_station.jpg',
    imageCaption: 'Space life-support and environmental sensors keep astronaut crews healthy on long journeys.',
    nasaFact:
      'Once your rocket reaches orbit and floats in microgravity on the way home to Earth, bodies do not feel weight anymore! Without heavy exercise, astronauts lose bone strength and muscle power, and seeing 16 sunrises a day can mess up sleep clocks.',
    olderKidsNote:
      'NASA space biology studies show astronauts work out ~2 hours every day, eat fresh space-grown veggies for their immune shield, and use blue-tuned cabin lighting to keep healthy sleep cycles on the long flight back from Mars.',
    classroomPrompt:
      'Crew Health Check: Which daily habits keep bones, muscles, sleep, and immune cells strong when floating in zero gravity?',
    gameContext:
      'Open the Space Facts Book -> Crew Health tab anytime to explore real space biology discoveries on bones, muscles, sleep, and immunity!',
    sourceName: 'NASA Open Science Data Repository',
    sourceUrl: 'https://osdr.nasa.gov/',
    missionId: 'mission_3',
    unlockedAtStage: 'm3_stage_5_orbital_dock',
    instrumentName: 'Space Biology & Dosimetry Lab',
    solObservation: 'Return Orbit Health',
    datasetType: 'REAL_NASA_OBSERVATION',
  },
];

export const DIALOGUE_SCRIPTS: Record<string, DialogueLine[]> = {
  opening_explore: [
    {
      id: 'op_1',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'We landed on Mars! Walk to the blue circle by the ship and press [E] to run a quick check.',
    },
  ],
  stage1_exit: [
    {
      id: 's1_1',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'Ship radio is down! Grab the spare part in the orange box [E], then ride the rover to the hill!',
    },
  ],
  stage2_crate: [
    {
      id: 's2_1',
      speaker: 'HAZALOOM',
      characterId: 'hazaloom',
      callsign: 'ASTRONAUT (YOU)',
      text: 'Got the power part! Hop in the rover with [E] — and grab yellow Solar Cells along the way!',
    },
  ],
  stage3_rover_enter: [
    {
      id: 's3_1',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'Rover online! Steer around rocks and follow the yellow arrow up to the radio tower!',
    },
  ],
  stage4_repaired: [
    {
      id: 's4_1',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'Dish locked on Earth! Nice tuning, Hazaloom!',
    },
  ],
  stage5_storm_alert: [
    {
      id: 's5_1',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'DUST STORM HERE! Race back inside the green circle at base right now!',
    },
  ],
  ending: [
    {
      id: 'end_1',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'Safe inside base! Mission 1 complete — Mission 2: Lava Cave is unlocked!',
    },
  ],

  m2_stage1_start: [
    {
      id: 'm2_s1_1',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'Hop in the rover [E] and follow the radar pings to drop Sensor 1!',
    },
  ],
  m2_beacon1_placed: [
    {
      id: 'm2_b1_1',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'Sensor 1 beeping! Drive north to drop Sensor 2 and map the lava cave!',
    },
  ],
  m2_beacon2_placed: [
    {
      id: 'm2_b2_1',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'Cave spotted! Head to the lava cave hole and press [E] to climb down!',
    },
  ],
  m2_cave_entry: [
    {
      id: 'm2_ce_1',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'Look — thick cave stone blocks 95% of space rays! Collect blue crystals and drill the glowing rock [E]!',
    },
  ],
  m2_sample_drilled: [
    {
      id: 'm2_sd_1',
      speaker: 'HAZALOOM',
      characterId: 'hazaloom',
      callsign: 'ASTRONAUT (YOU)',
      text: 'Rock Tube #14 sealed and packed!',
    },
  ],
  m2_tremor_alert: [
    {
      id: 'm2_ta_1',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'MARSQUAKE! Run back to the blue Cave Exit circle right now!',
    },
  ],
  m2_ending: [
    {
      id: 'm2_end_1',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'Made it out with Rock Tube #14! Mission 3: Rocket Home is unlocked!',
    },
  ],

  m3_stage1_start: [
    {
      id: 'm3_s1_1',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'Heater #2 is jammed! Walk to the rover and press [E] to flip the power switches!',
    },
  ],
  m3_bus_isolated: [
    {
      id: 'm3_bi_1',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'Power fixed! Drive east to the Mars Rocket pad — dodge dust tornadoes and grab Energy Cells!',
    },
  ],
  m3_dust_devil_hit: [
    {
      id: 'm3_dd_1',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'Whoa, dust tornado bump! Steer around those spinning swirls!',
    },
  ],
  m3_mav_reached: [
    {
      id: 'm3_mr_1',
      speaker: 'HAZALOOM',
      characterId: 'hazaloom',
      callsign: 'ASTRONAUT (YOU)',
      text: 'Mars Rocket pad ahead! Pull up to the yellow pad and press [E] to board!',
    },
  ],
  m3_launch_ignited: [
    {
      id: 'm3_li_1',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'BLAST OFF! Steer with [A] and [D] to keep the white line inside the green box!',
    },
  ],
  m3_stage1_burnout: [
    {
      id: 'm3_sb_1',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'Stage 1 empty! Press [SPACEBAR] to drop it and fire Rocket 2!',
    },
  ],
  m3_orbital_dock: [
    {
      id: 'm3_od_1',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'Welcome to microgravity! Use [WASD] or Arrows to steer into the spaceship ring!',
    },
  ],
  m3_ending: [
    {
      id: 'm3_end_1',
      speaker: 'HAZALOOM',
      characterId: 'hazaloom',
      callsign: 'ASTRONAUT (YOU)',
      text: 'DOCKED SAFE! Time to fly home to Earth!',
    },
  ],
};
